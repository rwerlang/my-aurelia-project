export interface ApplicantInputModel {
    name: string;
    familyName: string;
    address: string;
    countryOforigin: string;
    emailAddress: string;
    age?: number;
    hired: boolean
}
